﻿/* Implement a program that asks to the user for 2 parameters of a 2nd-grade equation, calculates the two solutions and prints them in Console. Handle the cases in which there are two solutions, one solution, or the equation is impossible or indeterminate.*/

// f(x)=ax^2 + bx +c 
// I have to find delta=b^2 - (4ab)
//if delta> we have two solutions, if delta is null, we have one solution and if it's neagative we have no solutions

using System;

namespace polinomio
{ 
    class program
    {
       public static void Main ()
        {
            double a = AskNumberToUser("insert the first number");
            double b = AskNumberToUser("insert the second number");
            double c = AskNumberToUser("insert the third number");
            double d;
            double e;
            double f;

            double delta = (b * b) - (4 * a * c);

                if (delta < 0) {
                    // no solutions
                    Console.WriteLine("non ci sono soluzioni");
                }
                

                else if (delta == 0) {
                    // one solution
                     d = -b / (2 * a) ;
                    Console.WriteLine("la soluzione è: " + d);
                }
                

                else {
                    // delta > 0
                    // two solutions
                    
                        e = (-b - Math.Sqrt(delta)) / (2 * a);                 
                        f = (-b + Math.Sqrt(delta)) / (2 * a);    

                        Console.WriteLine("the solutions are " + e + " and " +f);


                }
        }    
    
        static double AskNumberToUser(string message) {
            while (true) {
                Console.WriteLine(message);
                var input = Console.ReadLine();
                if (double.TryParse(input, out double number)) {
                    return number;
                }
                Console.WriteLine("Il numero inserito non è valido!");
            }
        }

       
    }
}