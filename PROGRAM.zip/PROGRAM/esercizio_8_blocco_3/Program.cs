﻿/*
Implement a program that calculates the Fibonacci's serie up to the n-th number, where n is given by the user, using a for / while loop.
*/

using System;
class fibonacci {
     public static void Main ()
    {

        int n = AskPositiveNumber("insert a number") ;
        Console.WriteLine(fib(n));
    }
static int fib(int n)
    {
         
        
        int []f = new int[n + 2];
        int i;
         
        
        f[0] = 0;
        f[1] = 1;
         
        for (i = 2; i <= n; i++)
        {
            /* sommo i due numeri antecedenti ad "i" */
            f[i] = f[i - 1] + f[i - 2];
        }
         
        return f[n];
    }
     
  static int AskPositiveNumber(string message) {
            while (true) {
                Console.WriteLine(message);
                var input = Console.ReadLine();
                if (int.TryParse(input, out int number)) {

                    if (number >0){
                         return number;
                    }
                }
                Console.WriteLine("Inserisci un numero intero positivo!");
            }
        }
    
}