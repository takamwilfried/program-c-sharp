﻿//Calculate the factorial of a number with recursion.
namespace Testing
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = AskNumberToUser("insert the number");
            Console.WriteLine(factorial_Recursion(n));
            Console.WriteLine("press any Key");
            Console.ReadLine();
        }

        static int AskNumberToUser(string message) {
            while (true) {
                Console.WriteLine(message);
                var input = Console.ReadLine();
                if (int.TryParse(input, out int number)) {
                    return number;
                }
                Console.WriteLine("Il numero inserito non è valido!");
            }
        }

        public static int factorial_Recursion(int number)
        {
            if (number == 1)
                return 1;
            else
                return number*factorial_Recursion(number - 1);
        }
    }
}